package com.seeds.NergetBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NergetBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
